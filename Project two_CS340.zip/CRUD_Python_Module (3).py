"""
CRUD Python Module for SNHU CS-340
This module supports Create, Read, Update, and Delete
operations on the 'animals' collection in the 'aac' database.
"""

from pymongo import MongoClient


class AnimalShelter:
    """
    CRUD operations for the 'animals' collection in the 'aac' database.
    """

    def __init__(
        self,
        username=None,
        password=None,
        host="localhost",
        port=27017,
        db_name="aac",
        collection_name="animals"
    ):
        """
        Initialize MongoDB client.

        NOTE: In the Codio CS-340 environment, MongoDB often reports
        "Access control is not enabled". For this assignment we still
        accept a username and password from the Dash dashboard (to show
        we can pass them through), but we do NOT use them in the URI.
        We connect without authentication.
        """

        # 🚫 DO NOT USE CREDENTIALS IN THE URI
        uri = f"mongodb://{host}:{port}/{db_name}"

        # Connect to MongoDB
        self.client = MongoClient(uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    # --------------------------------------------------------------
    # CREATE
    # --------------------------------------------------------------
    def create(self, data: dict):
        """
        Insert a new document into the collection.
        'data' must be a dictionary.
        Returns True if successful, False otherwise.
        """
        if data is not None and isinstance(data, dict):
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Create Error: {e}")
                return False
        else:
            raise Exception("Invalid data format: data must be a dictionary")

    # --------------------------------------------------------------
    # READ
    # --------------------------------------------------------------
    def read(self, query: dict):
        """
        Read documents matching the query.
        'query' must be a dictionary.
        Returns a cursor or empty list.
        """
        if query is not None and isinstance(query, dict):
            try:
                result = self.collection.find(query)
                return result
            except Exception as e:
                print(f"Read Error: {e}")
                return []
        else:
            raise Exception("Invalid query format: query must be a dictionary")

    # --------------------------------------------------------------
    # UPDATE
    # --------------------------------------------------------------
    def update(self, query: dict, new_values: dict):
        """
        Update documents matching query.
        Example: update({"name": "Lucy"}, {"$set": {"age": 5}})
        """
        if isinstance(query, dict) and isinstance(new_values, dict):
            try:
                result = self.collection.update_many(query, new_values)
                return result.raw_result
            except Exception as e:
                print(f"Update Error: {e}")
                return None
        else:
            raise Exception("Both query and new_values must be dictionaries")

    # --------------------------------------------------------------
    # DELETE
    # --------------------------------------------------------------
    def delete(self, query: dict):
        """
        Delete documents matching query.
        """
        if isinstance(query, dict):
            try:
                result = self.collection.delete_many(query)
                return result.raw_result
            except Exception as e:
                print(f"Delete Error: {e}")
                return None
        else:
            raise Exception("Query must be a dictionary")
