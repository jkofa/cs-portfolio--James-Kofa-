///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
// Edited by James Kofa
// 7-1 Final Project outcome, April 12, 2026
// Custom object created: coffee cup on saucer
// Shapes used: plane, cylinder, torus, and sphere
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	if (image)
	{
		std::cout << "Successfully loaded image: " << filename
			<< ", width: " << width
			<< ", height: " << height
			<< ", channels: " << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		}
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image: " << filename << std::endl;
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots. There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureSlot;
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return true;
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/**************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines the materials used by the objects
 *  in the scene so the lighting can show on each shape.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL woodMat;
	woodMat.tag = "wood";
	woodMat.ambientStrength = 0.45f;
	woodMat.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	woodMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	woodMat.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	woodMat.shininess = 12.0f;

	OBJECT_MATERIAL ceramicMat;
	ceramicMat.tag = "ceramic";
	ceramicMat.ambientStrength = 0.55f;
	ceramicMat.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramicMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramicMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramicMat.shininess = 96.0f;

	OBJECT_MATERIAL coffeeMat;
	coffeeMat.tag = "coffee";
	coffeeMat.ambientStrength = 0.40f;
	coffeeMat.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	coffeeMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	coffeeMat.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	coffeeMat.shininess = 8.0f;

	OBJECT_MATERIAL shinyMat;
	shinyMat.tag = "shiny";
	shinyMat.ambientStrength = 0.50f;
	shinyMat.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	shinyMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	shinyMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	shinyMat.shininess = 96.0f;

	m_objectMaterials.push_back(woodMat);
	m_objectMaterials.push_back(ceramicMat);
	m_objectMaterials.push_back(coffeeMat);
	m_objectMaterials.push_back(shinyMat);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Added two light sources in different positions.
 *  Light 0 is a white light and Light 1 is a colored light.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseLightingName, true);

		// Light 0 - main white light above and to the right
		m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(6.0f, 8.0f, 6.0f));
		m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.30f, 0.30f, 0.30f));
		m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.90f, 0.90f, 0.90f));
		m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
		m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
		m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.35f);

		// Light 1 - softer side fill light
		m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-3.0f, 2.0f, -2.0f));
		m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.10f, 0.10f, 0.10f));
		m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.50f, 0.50f, 0.50f));
		m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(1.0f, 0.8f, 0.6f));
		m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
		m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.15f);

		// Unused lights off
		for (int i = 2; i < 4; i++)
		{
			std::string index = std::to_string(i);
			m_pShaderManager->setVec3Value("lightSources[" + index + "].position", glm::vec3(0.0f, 0.0f, 0.0f));
			m_pShaderManager->setVec3Value("lightSources[" + index + "].ambientColor", glm::vec3(0.0f, 0.0f, 0.0f));
			m_pShaderManager->setVec3Value("lightSources[" + index + "].diffuseColor", glm::vec3(0.0f, 0.0f, 0.0f));
			m_pShaderManager->setVec3Value("lightSources[" + index + "].specularColor", glm::vec3(0.0f, 0.0f, 0.0f));
			m_pShaderManager->setFloatValue("lightSources[" + index + "].focalStrength", 1.0f);
			m_pShaderManager->setFloatValue("lightSources[" + index + "].specularIntensity", 0.0f);
		}
	}
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load meshes needed for the table and cup scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();

	// Define materials used by the textured objects
	DefineObjectMaterials();

	// Load textures
	CreateGLTexture("Source/Utilities/textures/wood.jpg", "wood");
	CreateGLTexture("Source/Utilities/textures/ceramic.jpg", "ceramic");
	CreateGLTexture("Source/Utilities/textures/coffee.jpg", "coffee");

	// Bind loaded textures
	BindGLTextures();
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Turn lighting on and apply scene lights
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseLightingName, true);
	}
	SetupSceneLights();

	/*************** TABLE / BASE PLANE ***************/
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("wood");
	SetTextureUVScale(3.0f, 3.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawPlaneMesh();

	/*************** SAUCER ***************/
	scaleXYZ = glm::vec3(4.5f, 0.30f, 4.5f);
	positionXYZ = glm::vec3(0.0f, 0.20f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawCylinderMesh();

	/*************** CUP BODY ***************/
	scaleXYZ = glm::vec3(2.0f, 2.3f, 2.0f);
	positionXYZ = glm::vec3(0.0f, 1.65f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawCylinderMesh();

	/*************** COFFEE SURFACE ***************/
	scaleXYZ = glm::vec3(1.6f, 0.15f, 1.6f);
	positionXYZ = glm::vec3(0.0f, 3.0f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("coffee");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("coffee");
	m_basicMeshes->DrawCylinderMesh();

	/*************** CUP HANDLE ***************/
	scaleXYZ = glm::vec3(1.0f, 1.0f, 0.40f);
	positionXYZ = glm::vec3(2.3f, 1.8f, 1.2f);

	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("ceramic");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTorusMesh();

	/*************** SMALL SPHERE ***************/
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);
	positionXYZ = glm::vec3(-1.5f, 0.55f, -0.5f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.6f, 1.0f, 1.0f);
	SetShaderMaterial("shiny");
	m_basicMeshes->DrawSphereMesh();

	/*************** SUGAR CUBE ***************/
	scaleXYZ = glm::vec3(0.45f, 0.45f, 0.45f);
	positionXYZ = glm::vec3(1.3f, 0.45f, -0.7f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.96f, 0.96f, 0.96f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawBoxMesh();
}