///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once


#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "ShaderManager.h"
#include "camera.h"

class ViewManager
{
public:
    // constructor
    ViewManager(ShaderManager* pShaderManager);

    // destructor
    ~ViewManager();

    // create OpenGL window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // mouse movement (LOOK AROUND)
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

    // mouse scroll (ZOOM)  ? THIS WAS MISSING
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

    // keyboard movement (WASD, Q/E, P/O)
    void ProcessKeyboardEvents();

    // prepare scene (view + projection)
    void PrepareSceneView();

private:
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;
};