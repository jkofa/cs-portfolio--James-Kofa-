// app_server/routes/travel.js

const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travel');

// Home page
router.get('/', travelController.home);

// Travel page
router.get('/travel', travelController.travel);

// About page
router.get('/about', travelController.about);

// Contact page
router.get('/contact', travelController.contact);

// Meals page
router.get('/meals', travelController.meals);

// News page
router.get('/news', travelController.news);

// Rooms page
router.get('/rooms', travelController.rooms);

module.exports = router;