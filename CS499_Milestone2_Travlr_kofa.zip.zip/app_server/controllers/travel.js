// app_server/controllers/travel.js

/**
 * Controller functions for the Travlr application.
 * These functions render the pages used in the project.
 */

// Home page
const home = (req, res, next) => {
  try {
    res.sendFile('index.html', { root: './public' });
  } catch (err) {
    next(err);
  }
};

// Travel page
const travel = (req, res, next) => {
  try {
    const pageData = {
      title: 'Travel',
      trips: [
        {
          name: 'Trip to Liberia',
          length: '7 days',
          cost: '$1200',
          description: 'Explore culture, food, and local attractions.'
        },
        {
          name: 'Trip to Ghana',
          length: '5 days',
          cost: '$950',
          description: 'Visit historical sites and enjoy city life.'
        },
        {
          name: 'Trip to Kenya',
          length: '8 days',
          cost: '$1450',
          description: 'Experience nature, wildlife, and adventure.'
        }
      ]
    };

    res.render('travel', pageData);
  } catch (err) {
    next(err);
  }
};

// About page
const about = (req, res, next) => {
  try {
    res.sendFile('about.html', { root: './public' });
  } catch (err) {
    next(err);
  }
};

// Contact page
const contact = (req, res, next) => {
  try {
    res.sendFile('contact.html', { root: './public' });
  } catch (err) {
    next(err);
  }
};

// Meals page
const meals = (req, res, next) => {
  try {
    res.sendFile('meals.html', { root: './public' });
  } catch (err) {
    next(err);
  }
};

// News page
const news = (req, res, next) => {
  try {
    res.sendFile('news.html', { root: './public' });
  } catch (err) {
    next(err);
  }
};

// Rooms page
const rooms = (req, res, next) => {
  try {
    res.sendFile('rooms.html', { root: './public' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  home,
  travel,
  about,
  contact,
  meals,
  news,
  rooms
};