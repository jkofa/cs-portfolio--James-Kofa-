// app.js (root)

const express = require('express');
const path = require('path');

const app = express();
const travelRoutes = require('./app_server/routes/travel');

// Set up port
const PORT = process.env.PORT || 3000;

// Middleware for reading form data and JSON
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set up Handlebars view engine
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Serve static files from public folder
app.use(express.static(path.join(__dirname, 'public')));

// Main application routes
app.use('/', travelRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).send('404 - Page not found');
});

// General error handler
app.use((err, req, res, next) => {
  console.error('Application error:', err.message);
  res.status(500).send('500 - Server error');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});