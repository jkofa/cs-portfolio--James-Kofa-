package com.example.sensormanagerdemo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

/**
 * MainActivity
 *
 * Inventory screen that:
 *  - Reads/writes items in a persistent SQLite database (CRUD)
 *  - Displays all items in a GridView
 *  - Sends SMS alerts when quantity falls below a minimum threshold
 *  - Continues to function even if SMS permission is denied
 */
public class MainActivity extends AppCompatActivity {

    // ---------- UI CONTROLS ----------
    private EditText etItemName;
    private EditText etQuantity;
    private EditText etMinQuantity;

    private Button btnAddItem;
    private Button btnUpdateItem;
    private Button btnDeleteItem;
    private Button btnClearFields;

    private GridView gvItems;

    // ---------- DATABASE ----------
    private DatabaseHelper dbHelper;

    // Remember which item is selected from the grid
    private int selectedItemId = -1;

    // Data used by the GridView adapter
    private ArrayList<String> itemDisplayList;
    private ArrayList<Integer> itemIdList;
    private ArrayAdapter<String> gridAdapter;

    // ---------- SMS PERMISSION / ALERTS ----------
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private boolean smsPermissionGranted = false;

    // Dummy phone number for alerts (emulator / instructor)
    private static final String ALERT_PHONE_NUMBER = "5554";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize all views
        initViews();

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Set up grid + adapter
        setupGrid();

        // Load all inventory items from database into grid (READ)
        loadItemsFromDb();

        // Ask user for SMS permission (2.1 / 2.2)
        checkSmsPermission();

        // Hook up button listeners (CRUD)
        setupButtonHandlers();

        // Handle grid item taps (for UPDATE / DELETE)
        setupGridClickListener();
    }

    // ---------------------------------------------------------------------
    // INITIALIZATION HELPERS
    // ---------------------------------------------------------------------

    /**
     * Finds all views from the layout.
     */
    private void initViews() {
        etItemName    = findViewById(R.id.etItemName);
        etQuantity    = findViewById(R.id.etQuantity);
        etMinQuantity = findViewById(R.id.etMinQuantity);

        btnAddItem     = findViewById(R.id.btnAddItem);
        btnUpdateItem  = findViewById(R.id.btnUpdateItem);
        btnDeleteItem  = findViewById(R.id.btnDeleteItem);
        btnClearFields = findViewById(R.id.btnClearFields);

        gvItems = findViewById(R.id.gvItems);
    }

    /**
     * Sets up ArrayLists and attaches the adapter to the GridView.
     */
    private void setupGrid() {
        itemDisplayList = new ArrayList<>();
        itemIdList      = new ArrayList<>();

        gridAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                itemDisplayList
        );
        gvItems.setAdapter(gridAdapter);
    }

    /**
     * Connects buttons to their CRUD actions.
     */
    private void setupButtonHandlers() {
        // CREATE
        btnAddItem.setOnClickListener(v -> addItem());

        // UPDATE
        btnUpdateItem.setOnClickListener(v -> updateItem());

        // DELETE
        btnDeleteItem.setOnClickListener(v -> deleteItem());

        // CLEAR
        btnClearFields.setOnClickListener(v -> clearFields());
    }

    /**
     * When a grid row is tapped, load that item into the input fields so the user
     * can update or delete it. (2.3, 2.4)
     */
    private void setupGridClickListener() {
        gvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    android.view.View view,
                                    int position,
                                    long id) {
                selectedItemId = itemIdList.get(position);

                // Our display string format is: "Name\nQty: X (Min: Y)"
                String display = itemDisplayList.get(position);
                String[] lines = display.split("\n");

                if (lines.length > 0) {
                    etItemName.setText(lines[0]);
                }

                if (lines.length > 1) {
                    String line2 = lines[1]; // "Qty: X (Min: Y)"
                    try {
                        String qtyPart = line2.substring(
                                line2.indexOf("Qty:") + 4,
                                line2.indexOf("(")
                        ).trim();

                        String minPart = line2.substring(
                                line2.indexOf("Min:") + 4,
                                line2.indexOf(")")
                        ).trim();

                        etQuantity.setText(qtyPart);
                        etMinQuantity.setText(minPart);
                    } catch (Exception e) {
                        // Ignore parsing errors – fields will just stay as-is
                    }
                }

                Toast.makeText(MainActivity.this,
                        "Selected item for update/delete",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ---------------------------------------------------------------------
    // SMS PERMISSION (2.1, 2.2) AND ALERTS (2.3)
    // ---------------------------------------------------------------------

    /**
     * Request SEND_SMS permission at runtime if it has not already been granted.
     */
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            smsPermissionGranted = true;

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    /**
     * Handle the result of the SMS permission request.
     * If denied, the rest of the app continues to work without SMS alerts.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                smsPermissionGranted = true;
                Toast.makeText(this,
                        "SMS permission granted. Alerts will be sent as text messages.",
                        Toast.LENGTH_LONG).show();

            } else {
                smsPermissionGranted = false;
                Toast.makeText(this,
                        "SMS permission denied. App will work without text alerts.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Sends a low-inventory SMS alert if:
     *  - the app has SMS permission, and
     *  - the current quantity is below the minimum quantity.
     */
    private void maybeSendLowStockAlert(String name, int qty, int minQty) {
        // Requirement: application must continue without this feature
        if (!smsPermissionGranted) {
            return;
        }

        if (qty >= minQty) {
            // No alert needed
            return;
        }

        String message = "Low inventory alert: " + name +
                " (Qty: " + qty + ", Min: " + minQty + ")";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    ALERT_PHONE_NUMBER,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(this,
                    "Low inventory SMS alert sent.",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this,
                    "Failed to send SMS alert.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------------
    // DATABASE + CRUD HELPERS (2.3, 2.4)
    // ---------------------------------------------------------------------

    /**
     * Reads all items from the database and populates the GridView.
     */
    private void loadItemsFromDb() {
        itemDisplayList.clear();
        itemIdList.clear();

        Cursor cursor = dbHelper.getAllItems();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id   = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
                int qty  = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_QTY));
                int min  = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_MIN_QTY));

                itemIdList.add(id);
                String display = name + "\nQty: " + qty + " (Min: " + min + ")";
                itemDisplayList.add(display);
            }
            cursor.close();
        }

        gridAdapter.notifyDataSetChanged();
    }

    /**
     * Validates user input and also ensures quantity fields are numeric.
     * (2.5 – prevents crashes and gives meaningful feedback)
     */
    private boolean validateFields() {
        // Basic empty checks
        if (TextUtils.isEmpty(etItemName.getText()) ||
                TextUtils.isEmpty(etQuantity.getText()) ||
                TextUtils.isEmpty(etMinQuantity.getText())) {

            Toast.makeText(this,
                    "Please fill in item name, quantity, and minimum quantity.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }

        // Numeric checks for quantity fields
        try {
            Integer.parseInt(etQuantity.getText().toString().trim());
            Integer.parseInt(etMinQuantity.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this,
                    "Quantity fields must be whole numbers.",
                    Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    // -------------------- CREATE --------------------
    private void addItem() {
        if (!validateFields()) return;

        String name = etItemName.getText().toString().trim();
        int qty     = Integer.parseInt(etQuantity.getText().toString().trim());
        int minQty  = Integer.parseInt(etMinQuantity.getText().toString().trim());

        long id = dbHelper.addItem(name, qty, minQty);

        if (id != -1) {
            Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();

            // Check for low inventory and maybe send SMS
            maybeSendLowStockAlert(name, qty, minQty);

            clearFields();
            loadItemsFromDb();
        } else {
            Toast.makeText(this, "Error adding item.", Toast.LENGTH_SHORT).show();
        }
    }

    // -------------------- UPDATE --------------------
    private void updateItem() {
        if (selectedItemId == -1) {
            Toast.makeText(this,
                    "Select an item from the grid first.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!validateFields()) return;

        String name = etItemName.getText().toString().trim();
        int qty     = Integer.parseInt(etQuantity.getText().toString().trim());
        int minQty  = Integer.parseInt(etMinQuantity.getText().toString().trim());

        int rows = dbHelper.updateItem(selectedItemId, name, qty, minQty);

        if (rows > 0) {
            Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show();

            // Check again after update
            maybeSendLowStockAlert(name, qty, minQty);

            clearFields();
            loadItemsFromDb();
        } else {
            Toast.makeText(this, "Error updating item.", Toast.LENGTH_SHORT).show();
        }
    }

    // -------------------- DELETE --------------------
    private void deleteItem() {
        if (selectedItemId == -1) {
            Toast.makeText(this,
                    "Select an item from the grid first.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int rows = dbHelper.deleteItem(selectedItemId);

        if (rows > 0) {
            Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
            clearFields();
            loadItemsFromDb();
        } else {
            Toast.makeText(this, "Error deleting item.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Clears all input fields and resets selection.
     */
    private void clearFields() {
        etItemName.setText("");
        etQuantity.setText("");
        etMinQuantity.setText("");
        selectedItemId = -1;
    }
}
