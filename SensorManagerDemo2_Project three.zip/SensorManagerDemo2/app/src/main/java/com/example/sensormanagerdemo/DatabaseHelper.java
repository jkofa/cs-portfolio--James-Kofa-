package com.example.sensormanagerdemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // --- Database info ---
    private static final String DB_NAME    = "inventory_app.db";
    private static final int    DB_VERSION = 1;

    // --- User table ---
    public static final String TABLE_USERS      = "users";
    public static final String COL_USER_ID     = "id";
    public static final String COL_USERNAME    = "username";
    public static final String COL_PASSWORD    = "password";

    // --- Inventory table ---
    public static final String TABLE_ITEMS      = "items";
    public static final String COL_ITEM_ID      = "id";
    public static final String COL_ITEM_NAME    = "name";
    public static final String COL_ITEM_QTY     = "quantity";
    public static final String COL_ITEM_MIN_QTY = "min_quantity";   // for low-stock alert

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " ("
                        + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COL_USERNAME + " TEXT UNIQUE, "
                        + COL_PASSWORD + " TEXT"
                        + ");";

        // Create inventory/items table
        String createItemsTable =
                "CREATE TABLE " + TABLE_ITEMS + " ("
                        + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COL_ITEM_NAME + " TEXT, "
                        + COL_ITEM_QTY + " INTEGER, "
                        + COL_ITEM_MIN_QTY + " INTEGER"
                        + ");";

        db.execSQL(createUsersTable);
        db.execSQL(createItemsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Simple reset for this project
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // ---------------------------------------------------------------------
    // USER METHODS  (used by LoginActivity)
    // ---------------------------------------------------------------------

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;   // true = insert OK, false = already exists / error
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean exists = (cursor != null && cursor.moveToFirst());

        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return exists;
    }

    // ---------------------------------------------------------------------
    // INVENTORY CRUD METHODS  (used by MainActivity later)
    // ---------------------------------------------------------------------

    // CREATE
    public long addItem(String name, int quantity, int minQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, quantity);
        values.put(COL_ITEM_MIN_QTY, minQuantity);

        long id = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return id;
    }

    // READ – returns all items for showing in a grid/list
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_ITEMS,
                null,
                null,
                null,
                null,
                null,
                COL_ITEM_NAME + " ASC"
        );
    }

    // UPDATE
    public int updateItem(int id, String name, int quantity, int minQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, quantity);
        values.put(COL_ITEM_MIN_QTY, minQuantity);

        int rows = db.update(
                TABLE_ITEMS,
                values,
                COL_ITEM_ID + " = ?",
                new String[]{ String.valueOf(id) }
        );

        db.close();
        return rows;
    }

    // DELETE
    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(
                TABLE_ITEMS,
                COL_ITEM_ID + " = ?",
                new String[]{ String.valueOf(id) }
        );
        db.close();
        return rows;
    }
}
